# 🌸 Sakura Sushi — Telegram Bot

Bu Telegram bot orqali sushi buyurtma qilish tizimi.

---

## 📁 Fayllar tarkibi

```
sakura_sushi_bot/
├── bot.py          — Asosiy bot kodi
├── config.py       — Sozlamalar (TOKEN va boshqalar)
├── menu.py         — Menyu (narx va tavsif)
├── database.py     — Ma'lumotlar bazasi
├── requirements.txt — Kerakli kutubxonalar
└── README.md       — Ushbu fayl
```

---

## 🚀 Ishga tushirish (Qadam-baqadam)

### 1. Bot Token olish

1. Telegramda **@BotFather** ga boring
2. `/newbot` yuboring
3. Bot nomini kiriting: `Sakura Sushi`
4. Bot username kiriting: `sakura_sushi_bot` (yoki boshqa)
5. Token oling — shunday ko'rinadi: `7123456789:AAFxxxxxx`

### 2. Admin Chat ID olish

1. Telegramda **@userinfobot** ga boring
2. `/start` yuboring
3. Sizning ID raqamingiz ko'rinadi (masalan: `987654321`)

### 3. config.py ni tahrirlash

```python
BOT_TOKEN = "7123456789:AAFxxxxxx"   # O'z tokeningiz
ADMIN_CHAT_ID = 987654321             # O'z ID raqamingiz
```

### 4. Python o'rnatish

```bash
# Python 3.10+ kerak
python --version
```

### 5. Kutubxonalarni o'rnatish

```bash
pip install -r requirements.txt
```

### 6. Botni ishga tushirish

```bash
python bot.py
```

---

## ⚙️ Menyuni sozlash

`menu.py` faylini oching va o'z mahsulotlaringizni qo'shing:

```python
{
    "name": "Filadelfiya",        # Nomi
    "description": "Losos, ...", # Tavsif
    "price": 45000,               # Narxi (so'mda)
    "emoji": "🌯"                 # Emoji
}
```

---

## 💳 Click to'lovini ulash

1. [merchant.click.uz](https://merchant.click.uz) ga boring
2. Ro'yxatdan o'ting
3. Yangi do'kon yarating
4. `config.py` ga Click ma'lumotlarini kiriting

---

## 🖥️ Server (Hosting) ga joylashtirish

Bot doimiy ishlashi uchun server kerak:

### Tavsiya etilgan serverlar:
- **Render.com** — bepul tarif mavjud
- **VPS (Kamatera, Timeweb)** — oyiga ~$3-5
- **Railway.app** — qulay va arzon

### PM2 bilan ishga tushirish (Linux):
```bash
npm install -g pm2
pm2 start bot.py --interpreter python3
pm2 save
pm2 startup
```

---

## 📊 Bot funksiyalari

| Funksiya | Tavsif |
|---|---|
| 🍣 Buyurtma berish | Kategoriya → Mahsulot → Miqdor |
| 🛒 Savatcha | Ko'rish, o'chirish, to'ldirish |
| 📍 Manzil | Geolokatsiya yoki matn |
| ⏰ Yetkazish vaqti | 4 ta variant |
| 💳 To'lov | Click yoki naqd |
| 📲 Admin xabarnomasi | Yangi buyurtmada darhol |
| ✅/❌ Status | Qabul qilish yoki rad etish |
| 📋 Buyurtmalar tarixi | So'nggi 10 ta |

---

## 📞 Yordam kerakmi?

Muammo bo'lsa, dasturchi bilan bog'laning.

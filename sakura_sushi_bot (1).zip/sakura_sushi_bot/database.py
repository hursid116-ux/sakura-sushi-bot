import sqlite3
import json
from datetime import datetime


class Database:
    def __init__(self, db_path="sakura_sushi.db"):
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        """Ma'lumotlar bazasini yaratish"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                user_name TEXT,
                phone TEXT,
                address TEXT,
                delivery_time TEXT,
                payment TEXT,
                cart TEXT,
                total INTEGER,
                status TEXT DEFAULT 'pending',
                created_at TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                phone TEXT,
                created_at TEXT
            )
        """)

        conn.commit()
        conn.close()

    def save_order(self, user_id, user_name, phone, address, delivery_time, payment, cart, total):
        """Yangi buyurtma saqlash"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO orders (user_id, user_name, phone, address, delivery_time, payment, cart, total, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
        """, (
            user_id, user_name, phone, address,
            delivery_time, payment,
            json.dumps(cart, ensure_ascii=False),
            total,
            datetime.now().strftime("%d.%m.%Y %H:%M")
        ))

        order_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return order_id

    def update_order_status(self, order_id, status):
        """Buyurtma statusini yangilash"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        conn.commit()
        conn.close()

    def get_user_orders(self, user_id):
        """Foydalanuvchi buyurtmalarini olish"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10",
            (user_id,)
        )
        orders = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return orders

    def get_all_orders(self, status=None):
        """Barcha buyurtmalarni olish (admin uchun)"""
        conn = self.get_connection()
        cursor = conn.cursor()
        if status:
            cursor.execute("SELECT * FROM orders WHERE status = ? ORDER BY id DESC", (status,))
        else:
            cursor.execute("SELECT * FROM orders ORDER BY id DESC")
        orders = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return orders

    def get_stats(self):
        """Statistika"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) as count, SUM(total) as revenue FROM orders WHERE status != 'rejected'")
        row = cursor.fetchone()
        conn.close()

        return {
            "total_orders": row["count"] or 0,
            "total_revenue": row["revenue"] or 0
        }

# =============================================
# SAKURA SUSHI - MENYU
# Bu yerda o'z menyungizni sozlang!
# =============================================

MENU = {
    "🌯 Rollar": [
        {
            "name": "Filadelfiya",
            "description": "Losos, krem-pishloq, bodring",
            "price": 45000,
            "emoji": "🌯"
        },
        {
            "name": "Kaliforniya",
            "description": "Krab, avokado, bodring",
            "price": 38000,
            "emoji": "🌯"
        },
        {
            "name": "Dragon Roll",
            "description": "Krevetka, avokado, yoyilma sous",
            "price": 52000,
            "emoji": "🌯"
        },
        {
            "name": "Spaysi Losos",
            "description": "Losos, spaysi sous, bodring",
            "price": 42000,
            "emoji": "🌯"
        },
        {
            "name": "Kavasaki",
            "description": "Tunets, bodring, krem-pishloq",
            "price": 48000,
            "emoji": "🌯"
        },
        {
            "name": "Sakura Roll",
            "description": "Krevetka, mango, avokado — bizning maxsus rolimiz!",
            "price": 55000,
            "emoji": "🌸"
        }
    ],

    "🍣 Sushi va Sashimi": [
        {
            "name": "Losos Sushi (2 dona)",
            "description": "Yangi losos ustida guruch",
            "price": 28000,
            "emoji": "🍣"
        },
        {
            "name": "Tunets Sushi (2 dona)",
            "description": "Yangi tunets ustida guruch",
            "price": 30000,
            "emoji": "🍣"
        },
        {
            "name": "Krevetka Sushi (2 dona)",
            "description": "Pishirilgan krevetka ustida guruch",
            "price": 25000,
            "emoji": "🍣"
        },
        {
            "name": "Losos Sashimi (5 dona)",
            "description": "Faqat yangi losos bo'laklari",
            "price": 55000,
            "emoji": "🍣"
        },
        {
            "name": "Assorted Sashimi (10 dona)",
            "description": "Turli xil baliq bo'laklari to'plami",
            "price": 95000,
            "emoji": "🍣"
        }
    ],

    "🍱 Setlar": [
        {
            "name": "Kichik Set",
            "description": "Filadelfiya + Kaliforniya + 4 dona sushi",
            "price": 85000,
            "emoji": "🍱"
        },
        {
            "name": "O'rta Set",
            "description": "3 ta rol + 6 dona sushi",
            "price": 135000,
            "emoji": "🍱"
        },
        {
            "name": "Katta Set",
            "description": "5 ta rol + 10 dona sushi + sashimi",
            "price": 220000,
            "emoji": "🍱"
        },
        {
            "name": "VIP Set",
            "description": "7 ta maxsus rol + 15 dona sushi + sashimi + desert",
            "price": 380000,
            "emoji": "👑"
        },
        {
            "name": "Juft Set (2 kishi uchun)",
            "description": "4 ta rol + 8 dona sushi — sevgilisi bilan!",
            "price": 165000,
            "emoji": "💑"
        }
    ],

    "🥗 Salatlar va Qo'shimchalar": [
        {
            "name": "Edamame",
            "description": "Tuzlangan yosh soya no'xat",
            "price": 18000,
            "emoji": "🥗"
        },
        {
            "name": "Miso Sho'rva",
            "description": "An'anaviy yapon sho'rvasi tofu bilan",
            "price": 22000,
            "emoji": "🍜"
        },
        {
            "name": "Chuka Salati",
            "description": "Dengiz o'ti salatı sesam yog'i bilan",
            "price": 25000,
            "emoji": "🥗"
        },
        {
            "name": "Gyoza (6 dona)",
            "description": "Qovurilgan dumpling go'sht bilan",
            "price": 32000,
            "emoji": "🥟"
        }
    ],

    "🥤 Ichimliklar": [
        {
            "name": "Yapon Choy",
            "description": "Yashil choy (teapot)",
            "price": 12000,
            "emoji": "🍵"
        },
        {
            "name": "Lemonad",
            "description": "Uy limonadi (0.5L)",
            "price": 18000,
            "emoji": "🍋"
        },
        {
            "name": "Coca-Cola",
            "description": "0.5L",
            "price": 10000,
            "emoji": "🥤"
        },
        {
            "name": "Mineral suv",
            "description": "0.5L",
            "price": 8000,
            "emoji": "💧"
        }
    ]
}

# =============================================
# SAKURA SUSHI BOT - KONFIGURATSIYA
# =============================================
# Bu yerga o'z ma'lumotlaringizni kiriting!

# 1. @BotFather dan olingan token
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# 2. Sizning Telegram chat ID (admin)
# Aniqlash uchun @userinfobot ga /start yuboring
ADMIN_CHAT_ID = 123456789  # O'zgartiring!

# 3. Restoran ma'lumotlari
RESTAURANT_NAME = "Sakura Sushi"
RESTAURANT_PHONE = "+998 90 123 45 67"
RESTAURANT_ADDRESS = "Toshkent sh., Chilonzor tumani"
WORKING_HOURS = "10:00 — 23:00"

# 4. Click to'lov karta raqami
CLICK_CARD_NUMBER = "8600 1234 5678 9012"
CLICK_CARD_OWNER = "Sakura Sushi"

# 5. Minimal buyurtma summasi (so'm)
MIN_ORDER_AMOUNT = 30000

# 6. Yetkazib berish narxi (so'm), 0 = bepul
DELIVERY_FEE = 0

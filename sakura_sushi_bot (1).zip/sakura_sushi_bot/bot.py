import logging
import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardRemove
)
from config import BOT_TOKEN, ADMIN_CHAT_ID
from menu import MENU
from database import Database

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
db = Database()


# ========================
# STATES
# ========================
class OrderStates(StatesGroup):
    choosing_category = State()
    choosing_item = State()
    choosing_quantity = State()
    viewing_cart = State()
    entering_name = State()
    entering_phone = State()
    entering_address = State()
    choosing_delivery_time = State()
    choosing_payment = State()
    confirming_order = State()


# ========================
# KEYBOARDS
# ========================
def main_menu_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🍣 Buyurtma berish")],
            [KeyboardButton(text="🛒 Savatcha"), KeyboardButton(text="📋 Mening buyurtmalarim")],
            [KeyboardButton(text="📞 Aloqa"), KeyboardButton(text="ℹ️ Haqida")]
        ],
        resize_keyboard=True
    )


def categories_keyboard():
    buttons = []
    for category in MENU.keys():
        buttons.append([KeyboardButton(text=category)])
    buttons.append([KeyboardButton(text="🔙 Orqaga")])
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)


def items_keyboard(category):
    buttons = []
    for item in MENU[category]:
        buttons.append([KeyboardButton(text=f"{item['name']} — {item['price']:,} so'm")])
    buttons.append([KeyboardButton(text="🛒 Savatchaga o'tish"), KeyboardButton(text="🔙 Orqaga")])
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)


def quantity_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="1"), KeyboardButton(text="2"), KeyboardButton(text="3")],
            [KeyboardButton(text="4"), KeyboardButton(text="5"), KeyboardButton(text="6")],
            [KeyboardButton(text="🔙 Orqaga")]
        ],
        resize_keyboard=True
    )


def cart_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="✅ Buyurtmani rasmiylashtirish")],
            [KeyboardButton(text="🗑 Savatchani tozalash"), KeyboardButton(text="🍣 Yana qo'shish")],
            [KeyboardButton(text="🔙 Bosh menyu")]
        ],
        resize_keyboard=True
    )


def payment_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="💳 Click orqali to'lash")],
            [KeyboardButton(text="💵 Naqd pul (yetkazganda)")],
            [KeyboardButton(text="🔙 Orqaga")]
        ],
        resize_keyboard=True
    )


def time_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="⚡ Imkon qadar tez")],
            [KeyboardButton(text="🕐 30 daqiqadan keyin"), KeyboardButton(text="🕑 1 soatdan keyin")],
            [KeyboardButton(text="🕒 2 soatdan keyin")],
            [KeyboardButton(text="🔙 Orqaga")]
        ],
        resize_keyboard=True
    )


def confirm_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="✅ Tasdiqlash")],
            [KeyboardButton(text="❌ Bekor qilish")]
        ],
        resize_keyboard=True
    )


def share_phone_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Telefon raqamimni yuborish", request_contact=True)],
            [KeyboardButton(text="🔙 Orqaga")]
        ],
        resize_keyboard=True
    )


def share_location_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📍 Manzilimni yuborish", request_location=True)],
            [KeyboardButton(text="✍️ Manzilni yozib kiritish")],
            [KeyboardButton(text="🔙 Orqaga")]
        ],
        resize_keyboard=True
    )


# ========================
# HELPERS
# ========================
def format_cart(cart: dict) -> str:
    if not cart:
        return "Savatcha bo'sh 🛒"
    
    text = "🛒 *Sizning savatchingiz:*\n\n"
    total = 0
    for i, (item_name, data) in enumerate(cart.items(), 1):
        subtotal = data['price'] * data['quantity']
        total += subtotal
        text += f"{i}. {item_name}\n"
        text += f"   {data['quantity']} x {data['price']:,} = {subtotal:,} so'm\n\n"
    
    text += f"━━━━━━━━━━━━━━\n"
    text += f"💰 *Jami: {total:,} so'm*"
    return text


def get_cart_total(cart: dict) -> int:
    return sum(data['price'] * data['quantity'] for data in cart.values())


# ========================
# HANDLERS
# ========================

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await state.clear()
    user_name = message.from_user.first_name
    await message.answer(
        f"🌸 Assalomu alaykum, *{user_name}*!\n\n"
        f"*Sakura Sushi*ga xush kelibsiz! 🍣\n\n"
        f"Bizda eng mazali va yangi sushilar tayyorlanadi.\n"
        f"Buyurtma berish uchun quyidagi menyudan foydalaning:",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard()
    )


@dp.message(F.text == "🍣 Buyurtma berish")
async def start_order(message: types.Message, state: FSMContext):
    await state.set_state(OrderStates.choosing_category)
    await state.update_data(cart={})
    await message.answer(
        "🍱 Kategoriyani tanlang:",
        reply_markup=categories_keyboard()
    )


@dp.message(F.text == "🔙 Bosh menyu")
async def back_to_main(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("Bosh menyu:", reply_markup=main_menu_keyboard())


@dp.message(OrderStates.choosing_category)
async def choose_category(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.clear()
        await message.answer("Bosh menyu:", reply_markup=main_menu_keyboard())
        return

    if message.text in MENU:
        await state.update_data(current_category=message.text)
        await state.set_state(OrderStates.choosing_item)

        items_text = f"*{message.text}*\n\n"
        for item in MENU[message.text]:
            items_text += f"🍣 *{item['name']}*\n"
            items_text += f"   {item['description']}\n"
            items_text += f"   💰 {item['price']:,} so'm\n\n"

        await message.answer(items_text, parse_mode="Markdown", reply_markup=items_keyboard(message.text))
    else:
        await message.answer("Iltimos, menyudan kategoriya tanlang:")


@dp.message(OrderStates.choosing_item)
async def choose_item(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.set_state(OrderStates.choosing_category)
        await message.answer("Kategoriyani tanlang:", reply_markup=categories_keyboard())
        return

    if message.text == "🛒 Savatchaga o'tish":
        data = await state.get_data()
        cart = data.get('cart', {})
        await state.set_state(OrderStates.viewing_cart)
        await message.answer(format_cart(cart), parse_mode="Markdown", reply_markup=cart_keyboard())
        return

    data = await state.get_data()
    category = data.get('current_category')

    # Find selected item
    selected_item = None
    for item in MENU.get(category, []):
        if message.text.startswith(item['name']):
            selected_item = item
            break

    if selected_item:
        await state.update_data(selected_item=selected_item)
        await state.set_state(OrderStates.choosing_quantity)
        await message.answer(
            f"✅ *{selected_item['name']}* tanlandi\n"
            f"💰 Narxi: {selected_item['price']:,} so'm\n\n"
            f"Nechta qo'shmoqchisiz?",
            parse_mode="Markdown",
            reply_markup=quantity_keyboard()
        )
    else:
        await message.answer("Iltimos, menyudan mahsulot tanlang:")


@dp.message(OrderStates.choosing_quantity)
async def choose_quantity(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        data = await state.get_data()
        category = data.get('current_category')
        await state.set_state(OrderStates.choosing_item)
        await message.answer("Mahsulot tanlang:", reply_markup=items_keyboard(category))
        return

    if message.text.isdigit() and 1 <= int(message.text) <= 20:
        quantity = int(message.text)
        data = await state.get_data()
        selected_item = data.get('selected_item')
        cart = data.get('cart', {})

        item_name = selected_item['name']
        if item_name in cart:
            cart[item_name]['quantity'] += quantity
        else:
            cart[item_name] = {
                'price': selected_item['price'],
                'quantity': quantity
            }

        await state.update_data(cart=cart)
        total = get_cart_total(cart)

        await message.answer(
            f"✅ *{item_name}* x{quantity} savatchaga qo'shildi!\n\n"
            f"🛒 Savatchadagi jami: *{total:,} so'm*\n\n"
            f"Yana qo'shasizmi yoki buyurtmani rasmiylashtirasizmi?",
            parse_mode="Markdown",
            reply_markup=items_keyboard(data.get('current_category'))
        )
        await state.set_state(OrderStates.choosing_item)
    else:
        await message.answer("Iltimos, 1-20 oralig'ida son kiriting:")


@dp.message(F.text == "🛒 Savatcha")
async def view_cart(message: types.Message, state: FSMContext):
    data = await state.get_data()
    cart = data.get('cart', {})
    await state.set_state(OrderStates.viewing_cart)
    await message.answer(format_cart(cart), parse_mode="Markdown", reply_markup=cart_keyboard())


@dp.message(OrderStates.viewing_cart)
async def handle_cart(message: types.Message, state: FSMContext):
    if message.text == "🗑 Savatchani tozalash":
        await state.update_data(cart={})
        await message.answer("✅ Savatcha tozalandi!", reply_markup=main_menu_keyboard())
        await state.clear()

    elif message.text == "🍣 Yana qo'shish":
        await state.set_state(OrderStates.choosing_category)
        await message.answer("Kategoriyani tanlang:", reply_markup=categories_keyboard())

    elif message.text == "🔙 Bosh menyu":
        await state.clear()
        await message.answer("Bosh menyu:", reply_markup=main_menu_keyboard())

    elif message.text == "✅ Buyurtmani rasmiylashtirish":
        data = await state.get_data()
        cart = data.get('cart', {})
        if not cart:
            await message.answer("❌ Savatcha bo'sh! Avval mahsulot qo'shing.")
            return

        await state.set_state(OrderStates.entering_name)
        await message.answer(
            "👤 Ismingizni kiriting:\n(Masalan: Abdulloh)",
            reply_markup=ReplyKeyboardRemove()
        )


@dp.message(OrderStates.entering_name)
async def enter_name(message: types.Message, state: FSMContext):
    if len(message.text) < 2:
        await message.answer("Iltimos, to'liq ismingizni kiriting:")
        return
    await state.update_data(customer_name=message.text)
    await state.set_state(OrderStates.entering_phone)
    await message.answer(
        "📱 Telefon raqamingizni yuboring:",
        reply_markup=share_phone_keyboard()
    )


@dp.message(OrderStates.entering_phone, F.contact)
async def enter_phone_contact(message: types.Message, state: FSMContext):
    phone = message.contact.phone_number
    await state.update_data(customer_phone=phone)
    await state.set_state(OrderStates.entering_address)
    await message.answer(
        "📍 Yetkazib berish manzilini yuboring yoki yozib kiriting:",
        reply_markup=share_location_keyboard()
    )


@dp.message(OrderStates.entering_phone)
async def enter_phone_text(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.set_state(OrderStates.entering_name)
        await message.answer("Ismingizni kiriting:", reply_markup=ReplyKeyboardRemove())
        return

    phone = message.text.strip()
    if len(phone) < 9:
        await message.answer("❌ Noto'g'ri raqam. Iltimos, qaytadan kiriting:")
        return

    await state.update_data(customer_phone=phone)
    await state.set_state(OrderStates.entering_address)
    await message.answer(
        "📍 Yetkazib berish manzilini yuboring yoki yozib kiriting:",
        reply_markup=share_location_keyboard()
    )


@dp.message(OrderStates.entering_address, F.location)
async def enter_address_location(message: types.Message, state: FSMContext):
    lat = message.location.latitude
    lon = message.location.longitude
    address = f"📍 Geolokatsiya: {lat:.4f}, {lon:.4f}"
    await state.update_data(customer_address=address, location=(lat, lon))
    await state.set_state(OrderStates.choosing_delivery_time)
    await message.answer("⏰ Qachon yetkazib berilsin?", reply_markup=time_keyboard())


@dp.message(OrderStates.entering_address)
async def enter_address_text(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.set_state(OrderStates.entering_phone)
        await message.answer("Telefon raqamingizni kiriting:", reply_markup=share_phone_keyboard())
        return

    if message.text == "✍️ Manzilni yozib kiritish":
        await message.answer("Manzilni yozing (ko'cha, uy raqami):", reply_markup=ReplyKeyboardRemove())
        return

    await state.update_data(customer_address=message.text)
    await state.set_state(OrderStates.choosing_delivery_time)
    await message.answer("⏰ Qachon yetkazib berilsin?", reply_markup=time_keyboard())


@dp.message(OrderStates.choosing_delivery_time)
async def choose_delivery_time(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.set_state(OrderStates.entering_address)
        await message.answer("Manzilni kiriting:", reply_markup=share_location_keyboard())
        return

    time_options = ["⚡ Imkon qadar tez", "🕐 30 daqiqadan keyin", "🕑 1 soatdan keyin", "🕒 2 soatdan keyin"]
    if message.text in time_options:
        await state.update_data(delivery_time=message.text)
        await state.set_state(OrderStates.choosing_payment)
        await message.answer("💳 To'lov usulini tanlang:", reply_markup=payment_keyboard())
    else:
        await message.answer("Iltimos, quyidagi variantlardan birini tanlang:")


@dp.message(OrderStates.choosing_payment)
async def choose_payment(message: types.Message, state: FSMContext):
    if message.text == "🔙 Orqaga":
        await state.set_state(OrderStates.choosing_delivery_time)
        await message.answer("Yetkazib berish vaqtini tanlang:", reply_markup=time_keyboard())
        return

    if message.text in ["💳 Click orqali to'lash", "💵 Naqd pul (yetkazganda)"]:
        await state.update_data(payment_method=message.text)
        data = await state.get_data()
        cart = data.get('cart', {})
        total = get_cart_total(cart)

        summary = (
            f"📋 *Buyurtma xulosasi:*\n\n"
            f"👤 Ism: {data.get('customer_name')}\n"
            f"📱 Tel: {data.get('customer_phone')}\n"
            f"📍 Manzil: {data.get('customer_address')}\n"
            f"⏰ Vaqt: {data.get('delivery_time')}\n"
            f"💳 To'lov: {data.get('payment_method')}\n\n"
            f"{format_cart(cart)}\n\n"
            f"Buyurtmani tasdiqlaysizmi?"
        )

        await state.set_state(OrderStates.confirming_order)
        await message.answer(summary, parse_mode="Markdown", reply_markup=confirm_keyboard())
    else:
        await message.answer("Iltimos, to'lov usulini tanlang:")


@dp.message(OrderStates.confirming_order)
async def confirm_order(message: types.Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("❌ Buyurtma bekor qilindi.", reply_markup=main_menu_keyboard())
        return

    if message.text == "✅ Tasdiqlash":
        data = await state.get_data()
        cart = data.get('cart', {})
        total = get_cart_total(cart)

        # Save order
        order_id = db.save_order(
            user_id=message.from_user.id,
            user_name=data.get('customer_name'),
            phone=data.get('customer_phone'),
            address=data.get('customer_address'),
            delivery_time=data.get('delivery_time'),
            payment=data.get('payment_method'),
            cart=cart,
            total=total
        )

        # Notify admin
        admin_text = (
            f"🔔 *YANGI BUYURTMA #{order_id}*\n\n"
            f"👤 Mijoz: {data.get('customer_name')}\n"
            f"📱 Tel: {data.get('customer_phone')}\n"
            f"📍 Manzil: {data.get('customer_address')}\n"
            f"⏰ Vaqt: {data.get('delivery_time')}\n"
            f"💳 To'lov: {data.get('payment_method')}\n\n"
        )

        for item_name, item_data in cart.items():
            admin_text += f"• {item_name} x{item_data['quantity']} = {item_data['price'] * item_data['quantity']:,} so'm\n"

        admin_text += f"\n💰 *JAMI: {total:,} so'm*"

        try:
            await bot.send_message(ADMIN_CHAT_ID, admin_text, parse_mode="Markdown")

            # Admin inline buttons
            admin_kb = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(text="✅ Qabul qilindi", callback_data=f"accept_{order_id}_{message.from_user.id}"),
                    InlineKeyboardButton(text="❌ Rad etish", callback_data=f"reject_{order_id}_{message.from_user.id}")
                ]
            ])
            await bot.send_message(ADMIN_CHAT_ID, f"Buyurtma #{order_id} uchun harakat:", reply_markup=admin_kb)
        except Exception as e:
            logger.error(f"Admin notification error: {e}")

        # Click payment
        if data.get('payment_method') == "💳 Click orqali to'lash":
            await message.answer(
                f"✅ *Buyurtma #{order_id} qabul qilindi!*\n\n"
                f"💳 Click orqali to'lash uchun:\n"
                f"Karta: *8600 1234 5678 9012*\n"
                f"Summa: *{total:,} so'm*\n"
                f"Izoh: *Buyurtma #{order_id}*\n\n"
                f"To'lovdan so'ng chekni yuboring! 📸\n\n"
                f"⏱ Yetkazib berish vaqti: 30-60 daqiqa",
                parse_mode="Markdown",
                reply_markup=main_menu_keyboard()
            )
        else:
            await message.answer(
                f"✅ *Buyurtma #{order_id} qabul qilindi!*\n\n"
                f"💵 To'lov: Naqd pul yetkazganda\n"
                f"💰 Summa: *{total:,} so'm*\n\n"
                f"⏱ Yetkazib berish vaqti: 30-60 daqiqa\n"
                f"📞 Muammo bo'lsa: +998 90 123 45 67",
                parse_mode="Markdown",
                reply_markup=main_menu_keyboard()
            )

        await state.clear()


# Admin callbacks
@dp.callback_query(F.data.startswith("accept_"))
async def accept_order(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    order_id = parts[1]
    user_id = int(parts[2])

    db.update_order_status(order_id, "accepted")

    await callback.message.edit_text(
        callback.message.text + f"\n\n✅ *QABUL QILINDI*",
        parse_mode="Markdown"
    )

    try:
        await bot.send_message(
            user_id,
            f"🎉 *Buyurtma #{order_id} qabul qilindi!*\n\n"
            f"Oshpazlar tayyorlashni boshladi 👨‍🍳\n"
            f"Tez orada yetkazib beriladi! 🛵",
            parse_mode="Markdown"
        )
    except:
        pass

    await callback.answer("✅ Buyurtma qabul qilindi!")


@dp.callback_query(F.data.startswith("reject_"))
async def reject_order(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    order_id = parts[1]
    user_id = int(parts[2])

    db.update_order_status(order_id, "rejected")

    await callback.message.edit_text(
        callback.message.text + f"\n\n❌ *RAD ETILDI*",
        parse_mode="Markdown"
    )

    try:
        await bot.send_message(
            user_id,
            f"😔 *Buyurtma #{order_id} rad etildi.*\n\n"
            f"Kechirasiz, hozirda qabul qila olmaymiz.\n"
            f"📞 Aloqa: +998 90 123 45 67",
            parse_mode="Markdown"
        )
    except:
        pass

    await callback.answer("❌ Buyurtma rad etildi!")


# Other handlers
@dp.message(F.text == "📋 Mening buyurtmalarim")
async def my_orders(message: types.Message):
    orders = db.get_user_orders(message.from_user.id)
    if not orders:
        await message.answer("📋 Sizda hali buyurtmalar yo'q.")
        return

    text = "📋 *Sizning buyurtmalaringiz:*\n\n"
    for order in orders[-5:]:
        status_emoji = {"pending": "⏳", "accepted": "✅", "rejected": "❌", "delivered": "🎉"}.get(order['status'], "⏳")
        text += f"{status_emoji} Buyurtma #{order['id']} — {order['total']:,} so'm\n"
        text += f"   📅 {order['created_at']}\n\n"

    await message.answer(text, parse_mode="Markdown")


@dp.message(F.text == "📞 Aloqa")
async def contact(message: types.Message):
    await message.answer(
        "📞 *Aloqa ma'lumotlari:*\n\n"
        "📱 Telefon: +998 90 123 45 67\n"
        "📱 Telefon: +998 91 123 45 67\n"
        "🕐 Ish vaqti: 10:00 — 23:00\n"
        "📍 Manzil: Toshkent sh., Chilonzor tumani\n\n"
        "💬 Telegram: @sakura_sushi_uz",
        parse_mode="Markdown"
    )


@dp.message(F.text == "ℹ️ Haqida")
async def about(message: types.Message):
    await message.answer(
        "🌸 *Sakura Sushi haqida:*\n\n"
        "Biz 2020-yildan buyon Toshkentda eng mazali va yangi sushilarni tayyorlab kelmoqdamiz.\n\n"
        "🏆 *Bizning afzalliklarimiz:*\n"
        "✅ Faqat yangi mahsulotlar\n"
        "✅ Tajribali oshpazlar\n"
        "✅ Tez yetkazib berish\n"
        "✅ Qulay narxlar\n\n"
        "🌐 Instagram: @sakura_sushi_uz",
        parse_mode="Markdown"
    )


async def main():
    logger.info("Sakura Sushi Bot ishga tushdi! 🌸")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
